import NftDetail from "@/components/nft/NftDetail";
import React from "react";
export const metadata = {
  title: "nft.assuredefi.com/?token=257",
  description: "Projects Assure DeFi® next app",
};
export default function NftPage() {
  return (
    <div>
      <NftDetail />
    </div>
  );
}
