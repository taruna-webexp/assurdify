(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_61af54.js",
  "chunks": [
    "static/chunks/_660363._.css",
    "static/chunks/node_modules_@mui_material_a27097._.js",
    "static/chunks/node_modules_@mui_system_esm_127ee5._.js",
    "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_6d4e8d._.js",
    "static/chunks/node_modules_@fortawesome_free-brands-svg-icons_index_mjs_660f2e._.js",
    "static/chunks/node_modules_d5b57b._.js",
    "static/chunks/src_a991f3._.js"
  ],
  "source": "dynamic"
});
