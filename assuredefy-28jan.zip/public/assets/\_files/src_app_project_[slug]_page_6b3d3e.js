(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_project_[slug]_page_6b3d3e.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_project_[slug]_page_6b3d3e.js",
  "chunks": [
    "static/chunks/src_4ba4f6._.js",
    "static/chunks/node_modules_0fc225._.js"
  ],
  "source": "dynamic"
});
