import Explore from "./project/page";


export default function Home() {
  return (
    <>
      <Explore />
    </>
  );
}
