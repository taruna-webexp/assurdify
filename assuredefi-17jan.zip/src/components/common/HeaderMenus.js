export const menus = [
    { Title: "About Us", path: `https://www.assuredefi.com/about` },
    { Title: "Verified Projects", path: `/` },
    {
        Title: "Services",
        path: ``,
        children: [
            { Title: "Code Audit", path: `https://www.assuredefi.com/code-audit` },
            { Title: "Growth Packages", path: `https://www.assuredefi.com/growth-packages` },
        ],
    },
    { Title: "Partners", path: `https://www.assuredefi.com/our-partner` },
    { Title: "Report A Scam", path: `https://www.assuredefi.com/report-a-scam` },
];
